package com.example.paymentapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PaymentAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
