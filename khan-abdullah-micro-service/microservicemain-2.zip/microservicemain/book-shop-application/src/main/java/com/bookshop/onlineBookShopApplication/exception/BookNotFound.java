package com.bookshop.onlineBookShopApplication.exception;

public class BookNotFound {


}
