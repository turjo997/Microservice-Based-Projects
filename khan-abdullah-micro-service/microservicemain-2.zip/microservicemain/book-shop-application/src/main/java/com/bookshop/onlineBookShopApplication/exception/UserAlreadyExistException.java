package com.bookshop.onlineBookShopApplication.exception;

public class UserAlreadyExistException  {
}
