package com.example.orderservice.service.impl;

public class OrderServiceImpl {
}
