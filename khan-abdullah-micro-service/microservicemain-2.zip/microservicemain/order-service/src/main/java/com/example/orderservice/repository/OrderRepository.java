package com.example.orderservice.repository;

public class OrderRepository {
}
