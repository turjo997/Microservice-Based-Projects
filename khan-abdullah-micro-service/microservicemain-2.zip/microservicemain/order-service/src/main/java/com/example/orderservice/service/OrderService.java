package com.example.orderservice.service;

public class OrderService {
}
